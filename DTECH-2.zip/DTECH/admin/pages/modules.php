<?php

require '../config/db.php';


$sel = "select * from duree";
$ex = mysqli_query($db, $sel);


?>

<form action="../config/conf.php" method="post" class="w-75" enctype="multipart/form-data" accept="">
    <div class="row mb-3">
        <div class="col">
            <input type="file" name="img" id="" class="form-control">
            <span class="error">
                <?php
                if (isset($_SESSION['img'])) {
                    echo $_SESSION['img'];
                }
                unset($_SESSION['img']);
                ?>
            </span>
        </div>
        <div class="col">
            <input type="text" name="code" id="" class="form-control" placeholder="code module" disabled>
            <span class="error">
                <?php
                if (isset($_SESSION['code'])) {
                    echo $_SESSION['code'];
                }
                unset($_SESSION['code']);
                ?>
            </span>
        </div>
    </div>
    <input type="text" name="nom" id="" placeholder="nom_module" class="form-control mb-3">
    <span class="error">
        <?php
        if (isset($_SESSION['nom'])) {
            echo $_SESSION['nom'];
        }
        unset($_SESSION['nom']);
        ?>
    </span>
    <textarea name="desc" id="" class="form-control" placeholder="description du module"></textarea>
    <span class="error">
        <?php
        if (isset($_SESSION['desc'])) {
            echo $_SESSION['desc'];
        }
        unset($_SESSION['desc']);
        ?>
    </span>
    <input type="text" name="prix" id="" class="form-control mt-3" placeholder="prix du module">
    <span class="error">
        <?php
        if (isset($_SESSION['prix'])) {
            echo $_SESSION['prix'];
        }
        unset($_SESSION['prix']);
        ?>
    </span>
    <div class="row mb-3 mt-3">
        <div class="col">
            <select name="duree" id="" class="form-control">
                <option value="">selectionner une durée</option>
                <?php
                while ($r = mysqli_fetch_assoc($ex)) { ?>
                <option value="<?=$r['duree']?>"><?=$r['duree']?></option>

                <?php   }
                ?>
            </select>
            <span class="error">
                <?php
                if (isset($_SESSION['duree'])) {
                    echo $_SESSION['duree'];
                }
                unset($_SESSION['duree']);
                ?>
            </span>
        </div>
        <div class="col">
            <select name="prof" id="" class="form-control">
                <option value="">prof</option>
                <option value="">ma duree</option>
            </select>
            <span class="error">
                <?php
                if (isset($_SESSION['prof'])) {
                    echo $_SESSION['prof'];
                }
                unset($_SESSION['prof']);
                ?>
            </span>
        </div>
    </div>
    <button type="submit" name="module" class="form-control bg-bleu text-blanc fw-bold">Ajouter</button>
</form>

L