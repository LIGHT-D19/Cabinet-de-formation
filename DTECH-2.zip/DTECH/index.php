<?php

session_start();

?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous"> -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="css/index.css">
    <title>DTECH Formation</title>
</head>

<body>

    <header>
        <nav class="navbar navbar-expand-lg navbar-danger bg-light">
            <div class="container">
                <a class="navbar-brand" href="#">
                    <img src="images/logo.png" alt srcset width="120">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse ms-5" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="#">Accueil</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Nos expertises</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">notre mission</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Contact</a>
                        </li>

                    </ul>
                    <form class="d-flex">
                        <button class="btn bg-bleu text-blanc" data-bs-toggle="modal" data-bs-target="#connexion" type="button">
                            <i class="fa-solid fa-right-to-bracket me-2"></i>
                            Se connecter
                        </button>
                        <button class="btn bg-success text-blanc ms-4" data-bs-toggle="modal" data-bs-target="#inscription" type="button">
                            <i class="fa-solid fa-right-to-bracket me-2"></i>
                            s'inscrire
                        </button>
                    </form>
                </div>
            </div>
        </nav>

        <div class="banner">
            <div class="container">
                <div class=" row w-100">
                    <div class="col text-blanc ">
                        <h1 class="text-uppercase fw-bold text-rouge">
                            devenez maitre de voter destinée
                        </h1>
                        <p class="text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Laboriosam sequi quos sint error minima quod sit ipsam repellat, delectus amet repellendus quaerat iure ipsa, aperiam omnis voluptate unde iste neque.</p>
                        <a href="" class="btn bg-bleu text-blanc">Explorez nos modules <i class="fa-solid fa-arrow-right ms-2"></i></a>
                    </div>
                    <div class="col">

                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- modal connexion -->
    <div class="modal fade" id="connexion" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title fw-bold text-bleu" id="exampleModalLabel">Connexion
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="config/conf.php" method="post">


                        <?php if (isset($_SESSION['erreur'])) { ?>
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <strong><?php echo $_SESSION['erreur']?></strong>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>

                            

                        <?php  }
                        unset($_SESSION['erreur']); ?>

                        <?php if (isset($_SESSION['bon'])) { ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <strong><?php echo $_SESSION['bon']?></strong>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>

                            

                        <?php  }
                        unset($_SESSION['bon']); ?>

                        <input type="email" name="email" id="" placeholder="votre email" class="form-control">
                        <input type="password" name="password" id="" placeholder="votre mot de passe" class="mt-3 form-control">
                        <button type="submit" name="connexion" class="mt-3 bg-bleu text-blanc form-control border-0">Se connecter</button>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Annuler</button>
                </div>
            </div>
        </div>
    </div>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/js/fontawesome.min.js" integrity="sha512-NeFv3hB6XGV+0y96NVxoWIkhrs1eC3KXBJ9OJiTFktvbzJ/0Kk7Rmm9hJ2/c2wJjy6wG0a0lIgehHjCTDLRwWw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

</body>

</html>