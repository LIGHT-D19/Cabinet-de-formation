<?php
session_start();
include("db.php");

// echo  "<pre>";
// var_dump($_POST);

// echo  "</pre>";

// connexion de l'admin

if (isset($_POST["connexion"])) {
    $email  = htmlspecialchars($_POST['email']);
    $password = htmlspecialchars($_POST['password']);

    if (empty($email) and empty($password)) {
        $_SESSION['erreur'] = "veuilez remplir tous les champs";
        header("location:../index.php");
    } elseif (empty($email) && !empty($password)) {
        $_SESSION['erreur'] = "veuilez entrer votre email";
        header("location:../index.php");
    } elseif (!empty($email) && empty($password)) {
        $_SESSION['erreur'] = "veuilez entrer votre mot de passe";
        header("location:../index.php");
    } else {
        $req = "SELECT email, pass from admin";
        $exec = mysqli_query($db, $req);
        $row = mysqli_fetch_assoc($exec);
        $admin_email = $row['email'];
        $admin_pass = $row["pass"];

        if (mysqli_num_rows($exec) > 0) {
            if ($admin_email === $email && $admin_pass === $password) {
                $_SESSION['admin'] = $email;
                header("location:../admin/index.php");
            } elseif ($admin_email !== $email and $admin_pass === $password) {
                $_SESSION['erreur'] = "email incorrect";
                header("location:../index.php");
            } elseif ($admin_email === $email and $admin_pass !== $password) {
                $_SESSION['erreur'] = "mot de passe incorrect";
                header("location:../index.php");
            }
        } else {
            $_SESSION['erreur'] = "aucun résultat trouvé";
            header("location:../index.php");
        }
    }
}



// déconnexion

if (isset($_GET['logout'])) {
    session_destroy();
    header('location:../index.php');
}

// gestion de durée

if (isset($_POST['ajoutDuree'])) {
    $duree = htmlspecialchars($_POST['duree']);
    if (empty($duree)) {
        $_SESSION['error'] = "veuillez entrer une durée";
        header('location:../admin/index.php?ajoutDuree');
    } else {
        $select_duree = "SELECT duree from duree where duree = '$duree'";
        $exec = mysqli_query($db, $select_duree);
        if (mysqli_num_rows($exec) > 0) {
            $_SESSION['duree'] = "La durée existe déjà";
            header('location:../admin/index.php?ajoutDuree');
        } else {
            $req  = mysqli_query($db, "INSERT INTO duree (duree) values ('$duree')");
            if ($req) {
                $_SESSION['bon'] = "Durée ajoutée avec succès";
                header('location:../admin/index.php?ajoutDuree');
            } else {
                echo "échoué";
            }
        }

        echo "<pre>";
        var_dump($exec);
        echo "</pre>";
    }
}



// gestion de modules

if (isset($_POST['module']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
    // $code = $_POST['code'];
    $nom = strtoupper($_POST['nom']);
    $desc = $_POST['desc'];
    $prix = $_POST['prix'];
    $duree = $_POST['duree'];
    $prof = $_POST['prof'];

    $image = $_FILES['img']['name'];
    $tmp = $_FILES['img']['tmp_name'];
    // if (empty($nom)) {
    //     $_SESSION['nom'] = "veuillez entrer le nom du module";
    //     header('location:../admin/index.php?modules');
    // }
    // if (empty($code)) {
    //     $_SESSION['code'] = "veuillez entrer le code du module";
    //     header('location:../admin/index.php?modules');
    // }

    // if (empty($desc)) {
    //     $_SESSION['desc'] = "veuillez entrer la description  du module";
    //     header('location:../admin/index.php?modules');
    // }

    // if (empty($prix)) {
    //     $_SESSION['prix'] = "veuillez entrer le prix du module";
    //     header('location:../admin/index.php?modules');
    // } else {
    //     if (!is_numeric($prix)) {
    //         $_SESSION['prix'] = "veuillez entrer un nombre";
    //         header('location:../admin/index.php?modules');
    //     }
    // }

    // if (empty($duree)) {
    //     $_SESSION['duree'] = "veuillez entrer la duree du module";
    //     header('location:../admin/index.php?modules');
    // }
    // if (empty($prof)) {
    //     $_SESSION['prof'] = "veuillez entrer l'enseignant  du module";
    //     header('location:../admin/index.php?modules');
    // }
    if (empty($image)) {
        $_SESSION['img'] = "veuillez choisir l'image du module";
        header('location:../admin/index.php?modules');
    } else {
        echo "<pre>";
        var_dump($_FILES);
        echo "</pre>";
    }

    if ($_FILES['img']['error'] === 0) {
        $bon = ["png", "jpg", "jpeg", "webp"];
        $extension = strtolower(pathinfo($image, PATHINFO_EXTENSION));
        if (in_array($extension, $bon)) {
            $name = strtoupper($nom) . '_' . date('Y').'.'.$extension;
            $id = substr($nom, 0, 4) . rand(1, 200);
            $ins = "INSERT INTO module (id_module, nom_module, description,prix,image,duree,nom) values ('$id', '$nom', '$desc', '$prix', '$name', '$duree', '')";
            $exec = mysqli_query($db, $ins);
            if ($exec) {
                mkdir("../admin/images_modules", 0777);
                move_uploaded_file($tmp,"../admin/images_modules/$name");
            } else {
                echo "échoué";
            }
            // echo "<pre>";
            // var_dump($name);
            // echo "</pre>";
            // mkdir("../admin/images_modules",0777);
        }
    }
}
