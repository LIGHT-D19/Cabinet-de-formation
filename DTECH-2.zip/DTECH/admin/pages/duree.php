<?php
require '../config/db.php';
$sd = mysqli_query($db, "SELECT * FROM duree");

// $sd = mysqli_fetch_assoc($sd);

echo "<pre>";
// var_dump($sd);
echo "</pre>"
?>


<div class="row">
    <div class="col">
        <form action="../config/conf.php" method="post">
            <?php if (isset($_SESSION['bon'])) { ?>
                <div class="alert alert-primary alert-dismissible fade show bg-bleu text-blanc" role="alert">
                    <strong><?php echo $_SESSION['bon'] ?></strong>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>



            <?php  }
            unset($_SESSION['bon']); ?>

            <?php if (isset($_SESSION['duree'])) { ?>
                <div class="alert alert-danger alert-dismissible fade show bg-rouge text-blanc" role="alert">
                    <strong><?php echo $_SESSION['duree'] ?></strong>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>



            <?php  }
            unset($_SESSION['duree']); ?>
            <input type="text" name="duree" placeholder="entrer une durée" class="form-control">
            <?php
            if (isset($_SESSION['error'])) { ?>
                <p class="error"><?= $_SESSION['error'] ?></p>

            <?php   }
            unset($_SESSION['error']);
            ?>
            <button type="submit" name="ajoutDuree" class="form-control bg-bleu text-blanc mt-3 w-50 border-0">Ajouter</button>
        </form>
    </div>
    <div class="col">
        <div class="card">
            <div class="card-header">
                <span class="h4">Durée ajoutée</span>
            </div>
            <div class="card-body">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col"># ID</th>
                            <th scope="col">Durée</th>
                            <th scope="col">Opérations</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        while ($row = mysqli_fetch_assoc($sd)) { ?>


                            <tr class="">
                                <th scope="row"><?= $row['id_duree'] ?></th>
                                <th scope="row"><?= $row['duree'] ?></th>

                                <td>
                                    <a href="" class="me-3">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="">
                                        <i class="fas fa-trash-alt text-danger"></i>
                                    </a>
                                </td>
                            </tr>


                        <?php  } ?>




                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>